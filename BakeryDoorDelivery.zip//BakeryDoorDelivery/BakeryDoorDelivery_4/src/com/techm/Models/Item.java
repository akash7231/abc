package com.techm.Models;

public class Item {
	private String itemId;
	private String itemName;
	private int price;
	private String dateOfPrep;
	private int quantityAvail;
	private String typeOfDelivery;
	
	public Item() {
		super();
	}

	public Item(String itemId, String itemName, int price, String dateOfPrep, int quantityAvail, String typeOfDelivery) {
		super();
		
//		if(typeOfDelivery.matches("HOME|NO_HOME")){
			this.itemId = itemId;
			this.itemName = itemName;
			this.price = price;
			this.dateOfPrep = dateOfPrep;
			this.quantityAvail = quantityAvail;
			this.typeOfDelivery = typeOfDelivery;
//		}
		
	}

	public String getItemId() {
		return itemId;
	}

	public void setItemId(String itemId) {
		this.itemId = itemId;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public String getDateOfPrep() {
		return dateOfPrep;
	}

	public void setDateOfPrep(String dateOfPrep) {
		this.dateOfPrep = dateOfPrep;
	}

	public int getQuantityAvail() {
		return quantityAvail;
	}

	public void setQuantityAvail(int quantityAvail) {
		this.quantityAvail = quantityAvail;
	}

	public String getTypeOfDelivery() {
		return typeOfDelivery;
	}

	public void setTypeOfDelivery(String typeOfDelivery) {
		this.typeOfDelivery = typeOfDelivery;
	}

	@Override
	public String toString() {
		return "item [itemId=" + itemId + ", itemName=" + itemName + ", price=" + price + ", dateOfPrep=" + dateOfPrep
				+ ", quantityAvail=" + quantityAvail + ", typeOfDelivery=" + typeOfDelivery + "]";
	}
		
}

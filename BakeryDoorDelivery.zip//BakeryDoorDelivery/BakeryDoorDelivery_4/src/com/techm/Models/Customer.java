package com.techm.Models;

public class Customer {

	private String  userId;
	private String password;
	private String custName;
	private String contactNo;
	private String emailId;
	
	private String doorno;// number(5),
	private String street;// varchar2(15),
	private String city;// varchar2(12),
	private String state;
	private String zip;

	public Customer() {
		super();
	}

	public Customer(String userId, String password, String custName,
			String contactNo, String emailId, String doorno,
			String street, String city, String state, String zip) {
		super();
		this.userId = userId;
		this.password = password;
		this.custName = custName;
		this.contactNo = contactNo;
		this.emailId = emailId;
		this.doorno = doorno;
		this.street = street;
		this.city = city;
		this.state = state;
		this.zip = zip;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getDoorno() {
		return doorno;
	}

	public void setDoorno(String doorno) {
		this.doorno = doorno;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getZip() {
		return zip;
	}

	public void setZip(String zip) {
		this.zip = zip;
	}

	@Override
	public String toString() {
		return "Customer [ city=" + city
				+ ", contactNo=" + contactNo + ", custName=" + custName
				+ ", doorno=" + doorno + ", emailId=" + emailId + ", password="
				+ password + ", state=" + state + ", street=" + street
				+ ", userId=" + userId + ", zip=" + zip + "]";
	}
	
	
	
	
}

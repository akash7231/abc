package com.techm.Models;

public class OrdList {

	private int listId;
	private String userId;
	private String status;
	private String itemId;
	private int quantityOrdered;

	public OrdList() {
		super();
	}

	public OrdList(int listId, String userId, String status, String itemId,
			int quantityOrdered) {
		super();
		this.listId = listId;
		this.userId = userId;
		this.status = status;
		this.itemId = itemId;
		this.quantityOrdered = quantityOrdered;
	}

	public int getListId() {
		return listId;
	}

	public void setListId(int listId) {
		this.listId = listId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getItemId() {
		return itemId;
	}

	public void setItemId(String itemId) {
		this.itemId = itemId;
	}

	public int getQuantityOrdered() {
		return quantityOrdered;
	}

	public void setQuantityOrdered(int quantityOrdered) {
		this.quantityOrdered = quantityOrdered;
	}

	@Override
	public String toString() {
		return "OrdList [itemId=" + itemId + ", listId=" + listId
				+ ", quantityOrdered=" + quantityOrdered + ", status=" + status
				+ ", userId=" + userId + "]";
	}

}

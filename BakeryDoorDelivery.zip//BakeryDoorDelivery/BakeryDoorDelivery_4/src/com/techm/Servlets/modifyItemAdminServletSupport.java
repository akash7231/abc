package com.techm.Servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import com.techm.Daos.ItemDao;
import com.techm.Models.Item;

public class modifyItemAdminServletSupport extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ItemDao itemDao;

	public void init(ServletConfig config) throws ServletException {
		itemDao=new ItemDao();
	}


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		boolean isValid=false;
		boolean isUpdated=false;
		
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		
		if(request.getParameter("itemId").isEmpty() || request.getParameter("itemName").isEmpty()){
			out.println("<body bgcolor=\"Cyan\">"
					+"<center>" 
					+"<h1>BAKERY DOOR DELIVERY</h1>"
					+"<h3>FIELDS CANT BE LEFT EMPTY</h3>"
					+ "</center>"
					+ "</body>");
		}else{
			
			Item item=new Item(request.getParameter("itemId"),
					request.getParameter("itemName"),
					Integer.parseInt(request.getParameter("price")),
					request.getParameter("dd")+"/"+request.getParameter("mm")+"/"+request.getParameter("yyyy"),
					Integer.parseInt(request.getParameter("quantityAvail")), 
					request.getParameter("typeOfDelivery"));

			isValid=itemDao.checkItemPresence(item);

			if (isValid==true) {
					System.out.println("---Item Found---");
					isUpdated=itemDao.updateItem(item);
					if (isUpdated==true) {
						System.out.println("---Item Updated---");
						
						RequestDispatcher rd=request.getRequestDispatcher("/menuForAdminServlet");
						rd.forward(request, response);
					}else {
						System.out.println("---Item Connat Be Updated---");
						
						RequestDispatcher rd=request.getRequestDispatcher("/menuForAdminServlet");
						rd.forward(request, response);
					}
					
			}else {
					System.out.println("---Error : 404 Item Not Found---");
	
					RequestDispatcher rd=request.getRequestDispatcher("/menuForAdminServlet");
					rd.forward(request, response);
			}
		}
	
	}
	
	@Override
	public void destroy() {
		itemDao=null;
	}

}

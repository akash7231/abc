package com.techm.Servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.techm.Models.Customer;

public class logoutServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void init(ServletConfig config) throws ServletException {
		
	}


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession();
		
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		
		Customer customer=(Customer)session.getAttribute("customer");
		
		session.invalidate();
		System.out.println("---"+customer.getUserId()+" logged out---");
		
		out.println("<body bgcolor='CYAN'>");
		out.println("<center>");
		out.println("<h1>BAKERY DOOR DELIVERY</h1><MARQUEE>WELCOME TO BIHAR BAKERY</MARQUEE>" );
		out.println("<h2> !!THANK YOU FOR SHOPPING WITH US !!</h2>");
		out.println("<h2>YOU HAVE BEEN SUCCESSFULLY LOGGED OUT... </h2>");
		out.println("<h4><A href=login.html>LOGIN AGAIN</A></h4>");
		out.println("<h4><A href=homepage.html>GO HOME</A></h4>");
		out.println("</center></body>");
	}

}

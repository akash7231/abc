package com.techm.Servlets;

import java.io.IOException;
//import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


import com.techm.Daos.ItemDao;
import com.techm.Models.Customer;
import com.techm.Models.Item;

public class addItemAdminServletSupport extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ItemDao itemDao=null;
	
	public void init(ServletConfig config) throws ServletException {
		itemDao=new ItemDao();
	}


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
	throws ServletException, IOException {
		
		HttpSession session=request.getSession();
		
		Customer customer=(Customer)session.getAttribute("customer");
		System.out.println(customer);
		
//		PrintWriter out=response.getWriter();
//		response.setContentType("text/html");
		
		boolean isAdded=false;
		
		isAdded=itemDao.addItem(new Item(request.getParameter("itemId"),
										request.getParameter("itemName"),
										Integer.parseInt(request.getParameter("price")),
										request.getParameter("dd")+"/"+request.getParameter("mm")+"/"+request.getParameter("yyyy"),
										Integer.parseInt(request.getParameter("quantityAvail")), 
										request.getParameter("typeOfDelivery")));
		
		if(isAdded==true){
			System.out.println("---Item Added---");
			RequestDispatcher rd=request.getRequestDispatcher("/menuForAdminServlet");
			rd.forward(request, response);
				
				
		}else{
			System.out.println("---Item Not Added---");
			RequestDispatcher rd=request.getRequestDispatcher("/menuForAdminServlet");
			rd.forward(request, response);
			
		}
		
	}

}

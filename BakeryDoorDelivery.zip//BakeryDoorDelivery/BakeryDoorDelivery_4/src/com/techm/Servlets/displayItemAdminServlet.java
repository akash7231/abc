package com.techm.Servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Iterator;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.techm.Daos.ItemDao;
import com.techm.Models.Customer;
import com.techm.Models.Item;


public class displayItemAdminServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ItemDao itemDao;

	public void init(ServletConfig config) throws ServletException {
		itemDao=new ItemDao();
	}


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ArrayList<Item> arrayList=itemDao.displayItems();
		HttpSession session=request.getSession();
		
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		
		Customer customer=(Customer) session.getAttribute("customer");
		
		out.println("<body bgcolor=\"Cyan\">" +
				"<center>"
					+"<h1>BAKERY DOOR DELIVERY</h1>"
					+"<MARQUEE>WELCOME TO BIHAR BAKERY</MARQUEE>" 
					+"<h3> HELLO "+customer.getUserId()+" (ADMIN) </h3>"
					+"<table border=\"1\">"
					+"<tr><td>ITEM ID</td><td>ITEM NAME</td><td>PRICE</td><td>DATE OF PREP</td>" 
					+"<td>QUANTITY AVAIL</td><td>TYPE OF DELIVERY</td></tr>");
		
		Iterator<Item> itr=arrayList.iterator();
		while (itr.hasNext()) {
			Item item = (Item) itr.next();
			out.println("<tr><td>"+item.getItemId()+"</td><td>"+item.getItemName()
						+"</td><td>"+new Integer(item.getPrice()).toString()
						+"</td><td>"+item.getDateOfPrep()+"</td><td>"
						+new Integer(item.getQuantityAvail())+"</td><td>"
						+item.getTypeOfDelivery()+"</td></tr>");
		}
		out.println("</table>" 
					+"<br><br><a href=\"menuForAdminServlet\">BACK TO MENU</a>" 				
					+"</center></body>");
	}

}

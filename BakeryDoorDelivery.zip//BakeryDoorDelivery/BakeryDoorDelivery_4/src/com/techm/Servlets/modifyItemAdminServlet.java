package com.techm.Servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.techm.Models.Customer;

public class modifyItemAdminServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;


	public void init(ServletConfig config) throws ServletException {
	}


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session=request.getSession();
		
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		
		Customer customer=(Customer) session.getAttribute("customer");
		
		out.println("<body bgcolor=\"Cyan\">" 
					+"<center>"
					+"<h1>BAKERY DOOR DELIVERY</h1>"
					+"<MARQUEE>WELCOME TO BIHAR BAKERY</MARQUEE>" 
					+"<h3> HELLO "+customer.getUserId()+" (ADMIN) </h3>"
					
					+"<form method=post action='modifyItemAdminServletSupport'>"
					
					+"<table border=\"1\">"
					+"<tr><td> ITEM ID </td> <td><input type=\"text\" name=\"itemId\"></td></tr>"
					+"<tr><td> ITEM NAME </td> <td><input type=\"text\" name=\"itemName\"></td></tr>"
					+"<tr><td> PRICE </td> <td><input type=\"text\" name=\"price\"></td></tr>"
					+"<tr><td> DATE OF PREPARATION </td><td colspan=\"3\">" 
						+"<input type=\"text\" size=\"2\" name=\"dd\">dd<b>/</b>"
						+"<input type=\"text\" size=\"2\" name=\"mm\">mm<b>/</b>"
						+"<input type=\"text\" size=\"2\" name=\"yyyy\">yyyy</td></tr>"
					+"<tr><td> QUANTITY AVAILABLE </td> <td><input type=\"text\" name=\"quantityAvail\"></td></tr>"
					+"<tr><td> TYPE OF DELIVERY </td> <td><input type=\"text\" name=\"typeOfDelivery\"></td></tr>"
					+"</table>" 
					+"<br><br><input type=\"submit\" value=\"CHECK ITEM\">" 
					+"<br><br><input type=\"reset\" value=\"CLEAR\">" 
					+"<br><br><a href=\"menuForAdminServlet\">BACK TO MENU</a>" 
					+"</form>" +
				
			"</center></body>");
	}

}

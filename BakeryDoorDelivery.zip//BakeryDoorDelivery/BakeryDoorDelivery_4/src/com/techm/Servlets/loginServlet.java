package com.techm.Servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.techm.Daos.CustomerDao;
import com.techm.Models.Customer;

public class loginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private CustomerDao customerDao=null;
	
	public void init(ServletConfig config) throws ServletException {
		customerDao=new CustomerDao();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			boolean isValid=false;
			PrintWriter out=response.getWriter();
			response.setContentType("text/html");
			
			HttpSession session=request.getSession();
			
			String userId=request.getParameter("userId");
			String password=request.getParameter("password");
			
			if(userId.isEmpty() || password.isEmpty()){
				out.println("<body bgcolor=\"Cyan\">"
						+"<center>" 
						+"<h1>BAKERY DOOR DELIVERY</h1>"
						+ "<h3>LOGIN UNSUCCESSFULLY !!</h3>"
						+"<h3>FIELDS CANT BE LEFT EMPTY</h3>"
						+ "<a href='login.html'> RE-LOGIN </a><br>"
						+ "<a href='homepage.html'>GO HOME </a>"
						+ "</center>"
						+ "</body>");
			}else{
					Customer customer=new Customer();
					customer.setUserId(userId);
					customer.setPassword(password);
					
					isValid=customerDao.checkCustomerPresence(customer);
					
					if(isValid==true){ //if customer
						System.out.println("---Customer Logged in---");
						session.setAttribute("customer", customer);
						
						RequestDispatcher requestDispatcherCustomer=request.getRequestDispatcher("/menuForCustomerServlet");
						requestDispatcherCustomer.forward(request, response);
						
					}else {
						
						if((customer.getUserId().compareTo("NIVEGA")==0 && customer.getPassword().compareTo("112233")==0)){
							System.out.println("--Admin logged in---");
							session.setAttribute("customer", customer);
							
							RequestDispatcher requestDispatcherAdmin=request.getRequestDispatcher("/menuForAdminServlet");
							requestDispatcherAdmin.forward(request, response);
							
						}else{
							response.sendRedirect
							("http://localhost:7001/BakeryDoorDelivery_486490/invaliduser.html");
						}
						
					}
			}
	}

}

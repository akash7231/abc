package com.techm.Daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.techm.Models.Customer;

public class CustomerDao{
			
	private Oracle oracle;	
	private Connection connection;
	
	public CustomerDao() {
		super();
		oracle=new Oracle();
		try {
			Class.forName(oracle.getDriverName());
			System.out.println("---Driver Loaded---");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	
	public CustomerDao(Oracle oracle) {
		super();
		this.oracle = oracle;
		try {
			Class.forName(oracle.getDriverName());
			System.out.println("---Driver Loaded---");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}


	
	public boolean addCustomer(Customer customer){ //FOR REGISTRATION
		connection=oracle.createConnection();
		boolean isAdded=false;
		
		String query="insert into customer values(?,?,?,?,?,"
						+"addresstype(?,?,?,?,?))";
		try {
			PreparedStatement ps=connection.prepareStatement(query);
			ps.clearParameters();
			
			ps.setString(1, customer.getUserId());
			ps.setString(2, customer.getPassword());
			ps.setString(3, customer.getCustName());
			ps.setString(4, customer.getContactNo());
			ps.setString(5, customer.getEmailId());
			ps.setString(6, customer.getDoorno());
			ps.setString(7, customer.getStreet());
			ps.setString(8, customer.getCity());
			ps.setString(9, customer.getState());
			ps.setString(10, customer.getZip());
			
			if(ps.executeUpdate()==1){
				System.out.println("---Customer Added---");
				isAdded=true;
			}
					
		} catch (SQLException e) {
			e.printStackTrace();
		}
				
		oracle.closeConnection(connection);
		return isAdded;
	}
	
	public boolean checkCustomerPresence(Customer customer){ //FOR LOGIN
		boolean isValid=false;
		connection=oracle.createConnection();
		String query="select * from customer where userid=? and password=?";
		
		try {
			PreparedStatement ps=this.connection.prepareStatement(query);
			ps.clearParameters();
			
			ps.setString(1, customer.getUserId());
			ps.setString(2, customer.getPassword());
			ResultSet resultSet=ps.executeQuery();
			if (resultSet.next()) {
				System.out.println("---Customer Found---");
				isValid=true;
			}
		
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		oracle.closeConnection(connection);
		return isValid;	
	}
	
}

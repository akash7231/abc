package com.techm.Daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;

import com.techm.Models.Item;

public class ItemDao{
	
	private Oracle oracle;	
	private Connection connection;
	
	
	public ItemDao() {
		super();
		oracle=new Oracle();
		try {
			Class.forName(oracle.getDriverName());
			System.out.println("---Driver Loaded---");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	public ItemDao(Oracle oracle) {
		super();
		this.oracle = oracle;
		try {
			Class.forName(oracle.getDriverName());
			System.out.println("---Driver Loaded---");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	public boolean addItem(Item item){
		boolean isAdded=false;
		connection=oracle.createConnection();
		
		String query="insert into item values(?,?,?,?,?,?)";

		try {
			PreparedStatement ps=connection.prepareStatement(query);
			ps.clearParameters();
			
			ps.setString(1, item.getItemId());
			ps.setString(2, item.getItemName());
			ps.setInt(3,item.getPrice());
			ps.setString(4, item.getDateOfPrep());
			ps.setInt(5, item.getQuantityAvail());
			ps.setString(6, item.getTypeOfDelivery());
			
			if (ps.executeUpdate()==1) {
				System.out.println("---Item Added---");
				isAdded=true;
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		oracle.closeConnection(connection);
		return isAdded;
	}
	
	public boolean checkItemPresence(Item item){
		boolean isValid=false;
		connection=oracle.createConnection();
		String query="select * from item where itemId=? and itemName=?";
		
		try {
			PreparedStatement ps=this.connection.prepareStatement(query);
			ps.clearParameters();
			
			ps.setString(1, item.getItemId());
			ps.setString(2, item.getItemName());
			
			ResultSet resultSet=ps.executeQuery();
			if (resultSet.next()) {
				System.out.println("---Item Found---");
				isValid=true;
			}
		
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		oracle.closeConnection(connection);
		return isValid;	
	}
	
	public boolean updateItem(Item item){
		boolean isUpdated=false;
		
		
		String query="update item set itemName=?, price=?, dateofprep=?," +
						" quantityAvail=?, typeofdelivery=? where itemid=?";
		connection=oracle.createConnection();
		
		try {
			PreparedStatement ps=connection.prepareStatement(query);
			ps.clearParameters();
			
			ps.setString(1, item.getItemName());
			ps.setInt(2, item.getPrice());
			ps.setString(3, item.getDateOfPrep());
			ps.setInt(4, item.getQuantityAvail());
			ps.setString(5, item.getTypeOfDelivery());
			ps.setString(6, item.getItemId());
			
			if (ps.executeUpdate()==1) {
				System.out.println("---Item Updated---");
				isUpdated=true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		oracle.closeConnection(connection);
		return isUpdated;
	}
	
	public ArrayList<Item> displayItems() {
		ArrayList<Item> arrayList=new ArrayList<Item>();
		String query="select * from item";
		connection=oracle.createConnection();
		
		try {
			PreparedStatement ps=connection.prepareStatement(query);
			ResultSet resultSet=ps.executeQuery();
			while (resultSet.next()) {
				arrayList.add(new Item(resultSet.getString("itemid"), 
										resultSet.getString("itemName"), 
										resultSet.getInt("price"),
										resultSet.getString("dateofprep"),
										resultSet.getInt("quantityAvail"),
										resultSet.getString("typeofdelivery")));
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		Iterator<Item> itr=arrayList.iterator();
		while (itr.hasNext()) {
			Item item = (Item) itr.next();
			System.out.println(item);
		}
		oracle.closeConnection(connection);
		return arrayList;
	}

	
	public boolean deleteItem(String itemId){
		boolean isDeleted=false;
		connection=oracle.createConnection();
		
		String query="delete item where itemid=?";

		try {
			PreparedStatement ps=connection.prepareStatement(query);
			ps.clearParameters();
			
			ps.setString(1, itemId);
			
			if (ps.executeUpdate()==1) {
				System.out.println("---Item Added---");
				isDeleted=true;
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		oracle.closeConnection(connection);
		return isDeleted;
	}
}

package com.techm.Daos;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Oracle {
	private String driverName="oracle.jdbc.OracleDriver";
	private String ConnectionUrl="jdbc:oracle:thin:@localhost:1521:ORCl";
	private String userName="scott";
	private String password="tiger";


	public Oracle() {
		super();
	}

	public Oracle(String driverName, String connectionUrl, String userName,
			String password, Connection connection) {
		super();
		this.driverName = driverName;
		this.ConnectionUrl = connectionUrl;
		this.userName = userName;
		this.password = password;
	}

	public String getDriverName() {
		return driverName;
	}

	public void setDriverName(String driverName) {
		this.driverName = driverName;
	}

	public String getConnectionUrl() {
		return ConnectionUrl;
	}

	public void setConnectionUrl(String connectionUrl) {
		ConnectionUrl = connectionUrl;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Connection createConnection(){
		Connection connection=null;
		try {
			connection=DriverManager.getConnection(ConnectionUrl, userName, password);
			System.out.println("---Connection Created---");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return connection;
	}
	
	public void closeConnection(Connection connection){
		if(connection != null){
			try {
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
}

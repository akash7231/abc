package com.techm.Daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.techm.Models.OrdList;

public class OrdListDao {

	private Oracle oracle;	
	private Connection connection;
	
	public OrdListDao() {
		super();
		oracle=new Oracle();
		try {
			Class.forName(oracle.getDriverName());
			System.out.println("---Driver Loaded---");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	public OrdListDao(Oracle oracle) {
		super();
		this.oracle = oracle;
		try {
			Class.forName(oracle.getDriverName());
			System.out.println("---Driver Loaded---");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	
	public boolean addOrder(int listId,String userId,String status,HashMap<String, Integer> ordList){ //FOR REGISTRATION
		connection=oracle.createConnection();
		boolean isAdded=false;
		
//		insert into ordlist values('5001','NIVE',IOTAB(ITEMSORDERED('1008',12),ITEMSORDERED('1022',12)));
//		Iterator<Map.Entry<String, Integer>> itr=ordList.entrySet().iterator();
//		while (itr.hasNext()) {
//			Map.Entry<String, Integer> entry = (Map.Entry<String, Integer>) itr.next();
//			System.out.println("CHECKBOXID="+entry.getKey()+" QUANTITY="+entry.getValue());
//		}
		
		String query="insert into ordlist values(?,?,?,IOTAB(";
		String subQuery="ITEMSORDERED(?,?)";
		
		for (int i = 0; i < ordList.size(); i++) {
			query+=subQuery;
			if(i<ordList.size()-1){
				query+=",";
			}
		}
		query+="))";
		
		System.out.println(query);
		System.out.println("ordList size="+ordList.size());
		
		try {
			PreparedStatement ps=connection.prepareStatement(query);
			ps.clearParameters();
			ps.setInt(1, listId);
			ps.setString(2, userId);
			ps.setString(3, status);
			
			Iterator<Map.Entry<String, Integer>> itr1=ordList.entrySet().iterator();
			int index=4;
			while (itr1.hasNext()) {
				Map.Entry<String, Integer> entry = (Map.Entry<String, Integer>) itr1.next();
				ps.setString(index, entry.getKey());
				ps.setInt(index+1, entry.getValue());
				index+=2;
//				System.out.println("CHECKBOXID="+entry.getKey()+" QUANTITY="+entry.getValue());
			}
			
			if(ps.executeUpdate()==1){
				System.out.println("---Customer Added---");
				isAdded=true;
			}
					
		} catch (SQLException e) {
			e.printStackTrace();
		}
				
		oracle.closeConnection(connection);
		return isAdded;
	}
	
	public int getLastListId() {
		String query = "select listId from ordlist";
		connection=oracle.createConnection();
		int listId=0;
		try {
			Statement st = connection.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
					ResultSet.CONCUR_UPDATABLE);
			ResultSet rs = st.executeQuery(query);
			rs.last();
			listId=rs.getInt("listid");
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		oracle.closeConnection(connection);
		return listId;
	}
	
	public ArrayList<OrdList> getOrderList(){
		connection=oracle.createConnection();
		ArrayList<OrdList> ordList=new ArrayList<OrdList>();
		OrdList oo=null;
		String query="select listId,userId,status from ordlist";

//		String query="select o.listId,o.userId,o.status,n.itemid,n.quantityordered from ordlist o,TABLE(list) n";
		
		
		try {
			PreparedStatement ps=connection.prepareStatement(query);
			ResultSet rs=ps.executeQuery();
			while (rs.next()) {
				oo=new OrdList();
				oo.setListId(rs.getInt("listid"));
				oo.setUserId(rs.getString("userid"));
				oo.setStatus(rs.getString("status"));
				ordList.add(oo);
			}
					
		} catch (SQLException e) {
			e.printStackTrace();
		}
				
		oracle.closeConnection(connection);
		return ordList;
	}
	public ArrayList<OrdList> getOrderList(int listId){
		connection=oracle.createConnection();
		ArrayList<OrdList> ordList=new ArrayList<OrdList>();
		
		String query="select o.listId,o.userId,o.status,n.itemid,n.quantityordered from ordlist o,TABLE(list) n where listId=?";
		
		
		try {
			PreparedStatement ps=connection.prepareStatement(query);
			ps.setInt(1, listId);
			ResultSet rs=ps.executeQuery();
			while (rs.next()) {
				ordList.add(new OrdList(rs.getInt("listId"), rs.getString("userid"), 
						rs.getString("status"), rs.getString("itemid"), rs.getInt("quantityordered") ));
			}
			
		Iterator<OrdList> itr=ordList.iterator();
		while (itr.hasNext()) {
			OrdList ordList2 = (OrdList) itr.next();
			System.out.println(ordList2);
		}
		
		} catch (SQLException e) {
			e.printStackTrace();
		}
				
		oracle.closeConnection(connection);
		return ordList;
	}
	
	public boolean setStatus(int listId,String status){
		connection=oracle.createConnection();
		boolean isUpdated=false;
		String query="update ordlist set status=? where listid=?";
		
		PreparedStatement ps;
		try {
			ps = connection.prepareStatement(query);
			ps.clearParameters();
			ps.setString(1, status);
			ps.setInt(2, listId);
			
			if (ps.executeUpdate()==1) {
				System.out.println("OrdList Updated");
				isUpdated=true;
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	
		oracle.closeConnection(connection);
		return isUpdated;
	}
	
	
}
